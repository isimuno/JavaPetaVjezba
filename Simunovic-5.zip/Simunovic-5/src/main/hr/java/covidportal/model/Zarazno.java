package main.hr.java.covidportal.model;

/**
 * Sucelje zarazno koje sadrzi metodu prelazakZarazeNaOsobu
 */
public interface Zarazno {

    void prelazakZarazeNaOsobu(Osoba osoba);
}
